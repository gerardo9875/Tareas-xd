﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maquinaexpendedora
{
    internal class Productos
    {
        string name;
        float price;
        int stock;

        public Productos(string name, float price, int stock)
        {
            this.name = name;
            this.price = price;
            this.stock = stock;
        }

        public string GetName()
        {
            return name;
        }

        public float GetPrice()
        {
            return price;
        }

        public int GetStock()
        {
            return stock;
        }



    }
}
