﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maquinaexpendedora
{
    internal class Menu
    {

        private Productos SelectProduct;

        public void Start()
        {
            CreateProductsMenu();
        }

        private void CreateProductsMenu()
        {
            bool ContinueFlag = true;

            while (ContinueFlag == true)
            {
                Console.WriteLine("Cree los productos que la máquina tiene");
                Console.WriteLine(("1. Introduzca el nombre del producto"));
                string name = Console.ReadLine();
                Console.WriteLine("2. Introduzca el precio del producto");
                float price = float.Parse(Console.ReadLine());
                Console.WriteLine("3. Introduzca el stock del producto");
                int stock = int.Parse(Console.ReadLine());
                Productos productos = new Productos(name, price, stock);
                Console.WriteLine("¿Desea continuar ingresando productos?");
                Console.WriteLine("1. Si"); Console.WriteLine("2.No");

                int valid = int.Parse(Console.ReadLine());
                if(valid == 2)
                {
                    ContinueFlag = false;
                }


            }

            Console.ReadLine();
        }

    }
}
