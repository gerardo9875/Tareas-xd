﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maquinaexpendedora
{
    internal class Monedas
    {
        float diezcent, veintecent, cincuentacent, unsol, dossoles, cincosoles;


        public Monedas(float diezcent, float veintecent, float cincuentacent, float unsol, float dossoles, float cincosoles)
        {

            this.diezcent = diezcent;
            this.veintecent = veintecent;
            this.cincuentacent = cincuentacent;
            this.unsol = unsol;
            this.dossoles = dossoles;
            this.cincosoles = cincosoles;
        }

        public float diezcen()
        {
            return diezcent;
        }

        public float veintezcen()
        {
            return veintecent;
        }

        public float cincuentacen()
        {
            return cincuentacent;
        }

        public float unso()
        {
            return unsol;
        }
        public float dossole()
        {
            return dossoles;
        }

        public float cincosole()
        {
            return cincosoles;
        }



    }
}
