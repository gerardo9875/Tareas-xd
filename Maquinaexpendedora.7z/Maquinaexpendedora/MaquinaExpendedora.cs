﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maquinaexpendedora
{
    internal class MaquinaExpendedora
    {
        List<Productos> ProductList;
        
        public MaquinaExpendedora(List<Productos> productList)
        {
            ProductList = productList; 
        }

        public List<Productos> Product
        {
            get
            {
                return ProductList;
            }
        }

        public void AddProduct(Productos product)
        {
            ProductList.Add(product);
        }

        public void RemoveProduct(Productos product)
        {
            ProductList.Remove(product);
        }
        
    }
}
